<?php

namespace Plugin\EccubePaymentLite42;

use Eccube\Common\EccubeTwigBlock;

class GmoEpsilonTwigBlock implements EccubeTwigBlock
{
    /**
     * @return array
     */
    public static function getTwigBlock()
    {
        return [
        ];
    }
}

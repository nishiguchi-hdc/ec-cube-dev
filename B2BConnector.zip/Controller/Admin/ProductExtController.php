<?php

namespace Plugin\B2BConnector\Controller\Admin;

use Eccube\Entity\Product;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\ProductClassRepository;
use Eccube\Entity\ProductClass;
use Plugin\B2BConnector\Entity\ProductExt;
use Plugin\B2BConnector\Entity\ProductClassExt;
use Plugin\B2BConnector\Repository\ProductExtRepository;
use Plugin\B2BConnector\Repository\ProductClassExtRepository;
use Plugin\B2BConnector\Form\Type\Admin\ProductExtType;
use Plugin\B2BConnector\Form\Type\Admin\ProductClassExtType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\FormFactoryInterface;
use Twig\Environment as TwigEnvironment;

class ProductExtController
{
    private TwigEnvironment $twig;
    private EntityManagerInterface $entityManager;
    private FormFactoryInterface $formFactory;
    private LoggerInterface $logger;
    private ProductExtRepository $productExtRepo;              // ★ 追加
    private ProductClassExtRepository $productClassExtRepo;    // ★ 追加

    public function __construct(
        TwigEnvironment $twig,
        EntityManagerInterface $entityManager,
        FormFactoryInterface $formFactory,
        LoggerInterface $logger,
        ProductExtRepository $productExtRepo,                  // ★ 追加
        ProductClassExtRepository $productClassExtRepo         // ★ 追加
    ) {
        $this->twig = $twig;
        $this->entityManager = $entityManager;
        $this->formFactory = $formFactory;
        $this->logger = $logger;
        $this->productExtRepo = $productExtRepo;               // ★ 追加
        $this->productClassExtRepo = $productClassExtRepo;     // ★ 追加
    }

    /**
     * 商品編集画面で表示される B2B拡張パネル
     */
    public function panel(Request $request, Product $Product): Response   // ★ Repository引数は外す
    {
        $this->logger->info('[B2BConnector] ProductExtController::panel start', ['product_id' => $Product->getId()]);

        // --- 商品拡張 ---
        $productExt = $this->productExtRepo->findOneBy(['Product' => $Product])
            ?? (new ProductExt())->setProduct($Product);

        // --- SKU拡張 ---
        $productClass = $Product->getProductClasses()->first(); // 1商品＝1SKU想定
        if (!$productClass) {
            // SKUが存在しない場合は作成
            $productClass = new \Eccube\Entity\ProductClass();
            $productClass->setProduct($Product);
            $this->entityManager->persist($productClass);
        }

        $classExt = $this->productClassExtRepo->findOneBy(['ProductClass' => $productClass])
            ?? (new ProductClassExt())->setProductClass($productClass);

        // --- フォーム生成 ---
        $formProductExt  = $this->formFactory->create(ProductExtType::class, $productExt);
        $formClassExt    = $this->formFactory->create(ProductClassExtType::class, $classExt);

        $html = $this->twig->render('@B2BConnector/admin/product_ext_fields.twig', [
            'Product' => $Product,
            'b2bconnector_form_product_ext'   => $formProductExt->createView(),
            'b2bconnector_form_class_ext' => $formClassExt->createView(),
        ]);

        return new Response($html);
    }

    
    public function panelNew(Request $request): Response
    {
        // Product は未作成。フォームだけ描画できれば良い。
        // 商品拡張フォーム用の空データ
        $productExt = new ProductExt();

        // SKU拡張フォーム用の空データ（ダミーの ProductClass に紐付け）
        $dummyClass = new ProductClass();
        $classExt = (new ProductClassExt())->setProductClass($dummyClass);

        // ← 新規画面でも FormView を作るのがポイント
        $formProductExt = $this->formFactory->create(ProductExtType::class, $productExt);
        $formClassExt   = $this->formFactory->create(ProductClassExtType::class, $classExt);

        $html = $this->twig->render('@B2BConnector/admin/product_ext_fields.twig', [
            'Product' => null, // 新規なので null
            'b2bconnector_form_product_ext' => $formProductExt->createView(),
            'b2bconnector_form_class_ext'   => $formClassExt->createView(),
        ]);

        return new Response($html);
    }
    
}

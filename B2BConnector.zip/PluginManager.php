<?php

namespace Plugin\B2BConnector;

use Eccube\Plugin\AbstractPluginManager;
use Eccube\Application;
use Doctrine\ORM\EntityManagerInterface;

class PluginManager extends AbstractPluginManager
{
    // public function install(array $meta, Application $app)
    // {
    //     // Migrationは自動実行される想定（composer.jsonのextraで指定）
    // }

    // public function uninstall(array $meta, Application $app)
    // {
    //     // 必要に応じてデータ保持 / 削除ポリシーを選択
    // }

    // public function enable(array $meta, Application $app)
    // {
    //     // 有効化時の初期処理（必要なら）
    // }

    // public function disable(array $meta, Application $app)
    // {
    //     // 無効化時の処理（必要なら）
    // }

    // public function update(array $meta, Application $app)
    // {
    //     // 版上げ時の処理（必要なら）
    // }
}

<?php

namespace Plugin\B2BConnector\Event;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Event\EccubeEvents;
use Eccube\Event\EventArgs;
use Eccube\Event\TemplateEvent;
use Plugin\B2BConnector\Entity\ProductClassExt;
use Plugin\B2BConnector\Entity\ProductExt;
use Plugin\B2BConnector\Form\Type\Admin\ProductClassExtType;
use Plugin\B2BConnector\Form\Type\Admin\ProductExtType;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormFactoryInterface;
use Twig\Environment;

class AdminProductSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private Environment $twig,
        private EntityManagerInterface $em,
        private FormFactoryInterface $formFactory,
        private LoggerInterface $logger
    ) {}

    public static function getSubscribedEvents()
    {
        return [
            EccubeEvents::ADMIN_PRODUCT_EDIT_INITIALIZE => 'onProductEditInitialize',
        ];
    }

    public function onProductEditInitialize(EventArgs $event): void
    {
        $req = $event->getRequest();
        $session = $req?->getSession();

        // POST時：拡張値を取り出す
        if ($req && $req->isMethod('POST')) {
            // フォームから来るキー名（あなたのログで確定済）
            $extData   = $req->request->all('product_ext');
            $classData = $req->request->all('product_class_ext');

            /** @var \Eccube\Entity\Product|null $Product */
            $Product = $event->getArgument('Product');

            if (!$Product || !$Product->getId()) {
                // まだ新規（ID無し） → セッション退避しておく
                if ($session) {
                    $session->set('b2b_pending_ext', [
                        'ext'   => $extData,
                        'class' => $classData,
                        'ts'    => time(),
                    ]);
                }
                return;
            }

            // ここまで来たら既にIDあり＝編集側POST。従来の保存ロジックでOK
            $this->saveExt($Product, $extData, $classData);
            return;
        }

        // GET時：新規作成直後の /edit にリダイレクトされたケースを捕まえる
        /** @var \Eccube\Entity\Product|null $Product */
        $Product = $event->getArgument('Product');
        if ($Product && $Product->getId() && $session && $session->has('b2b_pending_ext')) {
            $pending = $session->get('b2b_pending_ext');
            $session->remove('b2b_pending_ext'); // 一度だけ実行
            $extData   = \is_array($pending['ext'] ?? null) ? $pending['ext'] : [];
            $classData = \is_array($pending['class'] ?? null) ? $pending['class'] : [];
            $this->saveExt($Product, $extData, $classData);
        }
    }

    private function saveExt(\Eccube\Entity\Product $Product, array $extData, array $classData): void
    {
        $em = $this->em;

        // ProductExt
        $ProductExt = $em->getRepository(\Plugin\B2BConnector\Entity\ProductExt::class)
            ->findOneBy(['Product' => $Product]) ?? (new \Plugin\B2BConnector\Entity\ProductExt())->setProduct($Product);

        $ProductExt->setMadeIn($extData['made_in'] ?? $ProductExt->getMadeIn());
        $ProductExt->setSize($extData['size'] ?? $ProductExt->getSize());
        $ProductExt->setMaterial($extData['material'] ?? $ProductExt->getMaterial());
        if (\array_key_exists('weight', $extData))        { $ProductExt->setWeight($extData['weight']); }
        $ProductExt->setColorPattern($extData['color_pattern'] ?? $ProductExt->getColorPattern());
        $ProductExt->setPackageForm($extData['package_form'] ?? $ProductExt->getPackageForm());
        $ProductExt->setDescriptionSum($extData['description_sum'] ?? $ProductExt->getDescriptionSum());
        if (\array_key_exists('trade_rate', $extData))        { $ProductExt->setTradeRate($extData['trade_rate']); }
        $em->persist($ProductExt);

        // 1商品=1SKU
        $ProductClass = $Product->getProductClasses()->first();
        if ($ProductClass) {
            $ClassExt = $em->getRepository(\Plugin\B2BConnector\Entity\ProductClassExt::class)
                ->findOneBy(['ProductClass' => $ProductClass]) ?? (new \Plugin\B2BConnector\Entity\ProductClassExt())->setProductClass($ProductClass);

            $ClassExt->setItemCode($classData['item_code'] ?? $ClassExt->getItemCode());
            $ClassExt->setJanCode($classData['jan_code'] ?? $ClassExt->getJanCode());
            $ClassExt->setTaxCategory($classData['tax_category'] ?? $ClassExt->getTaxCategory());
            if (\array_key_exists('display_order', $classData)) { $ClassExt->setDisplayOrder((int)$classData['display_order']); }
            $ClassExt->setIsVisible(isset($classData['is_visible']) ? (bool)$classData['is_visible'] : $ClassExt->isVisible());
            if (\array_key_exists('pack_quantity', $classData))  { $ClassExt->setPackQuantity((int)$classData['pack_quantity']); }
            $ClassExt->setIsDiscounted(isset($classData['is_discounted']) ? (bool)$classData['is_discounted'] : $ClassExt->isDiscounted());

            $em->persist($ClassExt);
        }

        $em->flush();
    }
}
